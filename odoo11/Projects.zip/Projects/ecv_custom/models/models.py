# -*- coding: utf-8 -*-

from odoo import models, fields, api

class StockQuant(models.Model):
    _inherit = "stock.quant"

    standard_cost = fields.Float(string="Standard Price", related="product_tmpl_id.standard_price")
    total_cost = fields.Float(compute="_compute_total_on_hand")

    @api.one
    @api.depends("standard_cost", "quantity")
    def _compute_total_on_hand(self):
        self.total_cost = self.standard_cost * self.quantity
